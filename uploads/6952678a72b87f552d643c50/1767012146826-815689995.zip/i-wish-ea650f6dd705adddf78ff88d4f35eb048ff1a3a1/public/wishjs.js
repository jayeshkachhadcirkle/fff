// Hello From iWish JS File
// <script src="https://patient-prospect-hamilton-llp.trycloudflare.com/wishjs.js" defer></script>

console.log("Hello From iWish JS File");